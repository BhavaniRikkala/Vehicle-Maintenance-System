package com.cjits.controller;

import com.cjits.entity.Billing;
import com.cjits.service.BillingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/restapi/" +
        "billing")
public class BillingController {

    @Autowired
    private BillingService billingService;

    @GetMapping("/")
    public ResponseEntity<List<Billing>> getAllBillings() {
        List<Billing> billings = billingService.findAll();
        return ResponseEntity.ok(billings);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getBillingById(@PathVariable Long id) {
        Optional<Billing> billingOptional = billingService.findById(id);
        if (billingOptional.isPresent()) {
            return ResponseEntity.ok(billingOptional.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Billing not found with ID: " + id);
        }
    }

    @PostMapping("/")
    public ResponseEntity<Billing> createBilling(@RequestBody Billing billing) {
        Billing savedBilling = billingService.save(billing);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedBilling);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteBilling(@PathVariable Long id) {
        if (billingService.findById(id).isPresent()) {
            billingService.deleteById(id);
            return ResponseEntity.ok("Billing with ID: " + id + " deleted successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Billing not found with ID: " + id);
        }
    }
}
