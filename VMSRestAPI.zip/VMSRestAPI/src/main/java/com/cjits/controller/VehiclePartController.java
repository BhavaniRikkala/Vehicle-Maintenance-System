package com.cjits.controller;

import com.cjits.entity.VehiclePart;
import com.cjits.service.VehiclePartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/restapi/vehicle-parts")
public class VehiclePartController {

    @Autowired
    private VehiclePartService vehiclePartService;

    @GetMapping("/{id}")
    public ResponseEntity<?> getVehiclePartById(@PathVariable Long id) {
        VehiclePart vehiclePart = vehiclePartService.findById(id);
        if (vehiclePart != null) {
            return ResponseEntity.ok(vehiclePart);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Vehicle part not found with ID: " + id);
        }
    }

    @PostMapping
    public ResponseEntity<?> createVehiclePart(@RequestBody VehiclePart vehiclePart) {
        VehiclePart savedVehiclePart = vehiclePartService.save(vehiclePart);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedVehiclePart);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteVehiclePart(@PathVariable Long id) {
        if (vehiclePartService.findById(id) != null) {
            vehiclePartService.deleteById(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Vehicle part not found with ID: " + id);
        }
    }
}
