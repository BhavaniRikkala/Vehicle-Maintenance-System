package com.cjits.controller;

import com.cjits.entity.Login;
import com.cjits.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/restapi/login")
public class LoginController {

    @Autowired
    private LoginService loginService;

    @PostMapping("/authenticate")
    public ResponseEntity<String> authenticate(@RequestParam String username, @RequestParam String password) {
        boolean isAuthenticated = loginService.authenticate(username, password);
        if (isAuthenticated) {
            return ResponseEntity.ok("User authenticated successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid username or password.");
        }
    }

    @GetMapping("/{username}")
    public ResponseEntity<?> getUserByUsername(@PathVariable String username) {
        Login login = loginService.findByUsername(username);
        if (login != null) {
            return ResponseEntity.ok(login);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found with username: " + username);
        }
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Login login) {
        Login registeredLogin = loginService.register(login);
        return ResponseEntity.status(HttpStatus.CREATED).body(registeredLogin);
    }

    @PutMapping("/{loginId}")
    public ResponseEntity<?> updatePassword(@PathVariable String loginId, @RequestParam String newPassword) {
        Login updatedLogin = loginService.updatePassword(loginId, newPassword);
        if (updatedLogin != null) {
            return ResponseEntity.ok(updatedLogin);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Login not found with ID: " + loginId);
        }
    }

    @DeleteMapping("/{loginId}")
    public ResponseEntity<?> deleteLogin(@PathVariable String loginId) {
        boolean isDeleted = loginService.deleteLogin(loginId);
        if (isDeleted) {
            return ResponseEntity.ok("Login with ID: " + loginId + " deleted successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Login not found with ID: " + loginId);
        }
    }
}
