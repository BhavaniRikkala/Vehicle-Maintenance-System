package com.cjits.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "login")
public class Login {
    @Id
    @Column(name = "login_id", nullable = false, unique = true)
    private String loginId;

    @Column(name = "username")
    private String username;

    @Column(name = "password")
    private String password;

    @OneToOne
    @JoinColumn(name = "registration_id")
    private Registration registration;

    public Login() {
    }

    public Login(String loginId, String username, String password, Registration registration) {
        this.loginId = loginId;
        this.username = username;
        this.password = password;
        this.registration = registration;
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Registration getRegistration() {
        return registration;
    }

    public void setRegistration(Registration registration) {
        this.registration = registration;
    }
}
