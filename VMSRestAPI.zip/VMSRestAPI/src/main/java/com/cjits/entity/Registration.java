package com.cjits.entity;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "registration")
@SecondaryTable(name = "user", pkJoinColumns = @PrimaryKeyJoinColumn(name = "registration_id"))
public class Registration {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "username")
    private String username;

    @Column(name = "email")
    private String email;

    @Column(name = "address")
    private String address;

    @Column(name = "pincode")
    private String pincode;

    @Column(name = "mobile_number")
    private String mobileNumber;

    @Column(name = "password")
    private String password;
    @Column(name = "user_role")
    private String userRole;

    @OneToOne(mappedBy = "registration", cascade = CascadeType.ALL)
    private Login login;
    @OneToMany(mappedBy = "registration", cascade = CascadeType.ALL)
    private List<User> users;

    public Registration() {
    }

    public Registration(String username, String email, String address, String pincode, String mobileNumber, String password) {
        this.username = username;
        this.email = email;
        this.address = address;
        this.pincode = pincode;
        this.mobileNumber = mobileNumber;
        this.password = password;
    }

    // Getters and setters

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Login getLogin() {
        return login;
    }

    public void setLogin(Login login) {
        this.login = login;
    }
}
