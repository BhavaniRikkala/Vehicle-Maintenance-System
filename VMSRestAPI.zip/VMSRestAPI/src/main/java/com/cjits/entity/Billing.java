package com.cjits.entity;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "billing")
public class Billing {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "vehicle_id")
    private Vehicle vehicle;

    @Column(name = "amount")
    private double amount;

    @Column(name = "date")
    private Date date;

    @ManyToOne
    @JoinColumn(name = "job_id")
    private Job job;

    public Billing() {
    }

    public Billing(Vehicle vehicle, double amount, Date date, Job job) {
        this.vehicle = vehicle;
        this.amount = amount;
        this.date = date;
        this.job = job;
    }

    // Getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Job getJob() {
        return job;
    }

    public void setJob(Job job) {
        this.job = job;
    }
}
