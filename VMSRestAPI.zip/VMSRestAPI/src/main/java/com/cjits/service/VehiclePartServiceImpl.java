package com.cjits.service;

import com.cjits.entity.VehiclePart;
import com.cjits.repository.VehiclePartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VehiclePartServiceImpl implements VehiclePartService {

    @Autowired
    private VehiclePartRepository vehiclePartRepository;

    @Override
    public VehiclePart findById(Long id) {
        return vehiclePartRepository.findById(id).orElse(null);
    }

    @Override
    public VehiclePart save(VehiclePart vehiclePart) {
        return vehiclePartRepository.save(vehiclePart);
    }

    @Override
    public void deleteById(Long id) {
        vehiclePartRepository.deleteById(id);
    }
}
