package com.cjits.service;

import com.cjits.entity.Login;

public interface LoginService {
    Login findByLoginId(String loginId);

    boolean authenticate(String username, String password);
    Login findByUsername(String username);
    Login register(Login login);
    Login updatePassword(String loginId, String newPassword);
    boolean deleteLogin(String loginId);
}
