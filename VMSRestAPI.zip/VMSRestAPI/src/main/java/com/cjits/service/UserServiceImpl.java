package com.cjits.service;

import com.cjits.entity.User;
import com.cjits.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public User findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    @Override
    public String register(User user) {
        // Add logic to validate user before saving
        try {
            userRepository.save(user);
            return "User registered successfully.";
        } catch (Exception e) {
            return "Failed to register user: " + e.getMessage();
        }
    }

    @Override
    public User updateUser(Long id, User user) {
        try {
            // Add logic to update user
            return userRepository.save(user);
        } catch (Exception e) {
            // Log the error or handle it accordingly
            return null;
        }
    }

    @Override
    public String deleteUser(Long id) {
        try {
            // Add logic to delete user
            userRepository.deleteById(id);
            return "User deleted successfully.";
        } catch (Exception e) {
            return "Failed to delete user: " + e.getMessage();
        }
    }
}
