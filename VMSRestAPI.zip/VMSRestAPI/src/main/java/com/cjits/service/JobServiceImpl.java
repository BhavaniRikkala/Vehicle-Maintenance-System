package com.cjits.service;

import com.cjits.entity.Job;
import com.cjits.repository.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class JobServiceImpl implements JobService {

    @Autowired
    private JobRepository jobRepository;

    @Override
    public Job findById(Long id) {
        return jobRepository.findById(id).orElse(null);
    }

    @Override
    public Job createJob(Job job) {
        return jobRepository.save(job);
    }

    @Override
    public Job updateJob(Long id, Job job) {
        Job existingJob = findById(id);
        if (existingJob != null) {
            job.setId(id);
            return jobRepository.save(job);
        }
        return null;
    }

    @Override
    public boolean deleteJob(Long id) {
        if (findById(id) != null) {
            jobRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
