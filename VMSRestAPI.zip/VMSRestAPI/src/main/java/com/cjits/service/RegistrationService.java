package com.cjits.service;

import com.cjits.entity.Registration;

public interface RegistrationService {
    Registration findByUsername(String username);
    boolean register(Registration registration);
    Registration updateRegistration(Long id, Registration registration);
    boolean deleteRegistration(Long id);
}
