package com.cjits.service;

import com.cjits.entity.User;

public interface UserService {
    User findByUsername(String username);
    String register(User user);
    User updateUser(Long id, User user);
    String deleteUser(Long id);
}
