package com.cjits.service;

import com.cjits.entity.VehiclePart;

public interface VehiclePartService {
    VehiclePart findById(Long id);
    VehiclePart save(VehiclePart vehiclePart);
    void deleteById(Long id);
}
