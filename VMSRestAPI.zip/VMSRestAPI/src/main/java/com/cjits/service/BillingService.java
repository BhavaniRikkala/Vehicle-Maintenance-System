package com.cjits.service;

import com.cjits.entity.Billing;
import java.util.List;
import java.util.Optional;

public interface BillingService {
    List<Billing> findAll();
    Optional<Billing> findById(Long id);
    Billing save(Billing billing);
    void deleteById(Long id);
}
