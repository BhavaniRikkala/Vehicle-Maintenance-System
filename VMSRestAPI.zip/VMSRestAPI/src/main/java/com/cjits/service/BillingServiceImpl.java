package com.cjits.service;

import com.cjits.entity.Billing;
import com.cjits.repository.BillingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class BillingServiceImpl implements BillingService {

    @Autowired
    private BillingRepository billingRepository;

    @Override
    public List<Billing> findAll() {
        return billingRepository.findAll();
    }

    @Override
    public Optional<Billing> findById(Long id) {
        return billingRepository.findById(id);
    }

    @Override
    public Billing save(Billing billing) {
        return billingRepository.save(billing);
    }

    @Override
    public void deleteById(Long id) {
        billingRepository.deleteById(id);
    }
}
