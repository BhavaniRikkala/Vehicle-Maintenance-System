package com.cjits.service;

import com.cjits.entity.Job;

public interface JobService {
    Job findById(Long id);
    Job createJob(Job job);
    Job updateJob(Long id, Job job);
    boolean deleteJob(Long id);
}
