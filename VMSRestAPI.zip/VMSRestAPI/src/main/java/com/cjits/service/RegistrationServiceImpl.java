package com.cjits.service;

import com.cjits.entity.Registration;
import com.cjits.repository.RegistrationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RegistrationServiceImpl implements RegistrationService {

    @Autowired
    private RegistrationRepository registrationRepository;

    @Override
    public Registration findByUsername(String username) {
        return registrationRepository.findByUsername(username);
    }

    @Override
    public boolean register(Registration registration) {
        if (registrationRepository.findByUsername(registration.getUsername()) == null) {
            registrationRepository.save(registration);
            return true;
        } else {
            return false;
        }
    }

    @Override
    public Registration updateRegistration(Long id, Registration registration) {
        Registration existingRegistration = registrationRepository.findById(id).orElse(null);
        if (existingRegistration != null) {
            existingRegistration.setUsername(registration.getUsername());
            existingRegistration.setEmail(registration.getEmail());
            existingRegistration.setAddress(registration.getAddress());
            existingRegistration.setPincode(registration.getPincode());
            existingRegistration.setMobileNumber(registration.getMobileNumber());
            existingRegistration.setPassword(registration.getPassword());
            return registrationRepository.save(existingRegistration);
        } else {
            return null; // Registration with given ID not found
        }
    }

    @Override
    public boolean deleteRegistration(Long id) {
        if (registrationRepository.existsById(id)) {
            registrationRepository.deleteById(id);
            return true;
        } else {
            return false; // Registration with given ID not found
        }
    }
}
