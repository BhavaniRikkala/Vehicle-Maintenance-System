package com.cjits.service;

import com.cjits.entity.Login;
import com.cjits.repository.LoginRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public abstract class LoginServiceImpl implements LoginService {

    @Autowired
    private LoginRepository loginRepository;
    @Override
    public Login findByLoginId(String loginId) {
        return loginRepository.findByLoginId(loginId);
    }
    @Override
    public boolean authenticate(String username, String password) {
        Login user = loginRepository.findByUsername(username);
        return user != null && user.getPassword().equals(password);
    }

    @Override
    public Login register(Login login) {
        return loginRepository.save(login);
    }

    @Override
    public Login updatePassword(String loginId, String newPassword) {
        Login user = loginRepository.findByLoginId(loginId);
        if (user != null) {
            user.setPassword(newPassword);
            return loginRepository.save(user);
        }
        return null;
    }

    @Override
    public boolean deleteLogin(String loginId) {
        Login user = loginRepository.findByLoginId(loginId);
        if (user != null) {
            loginRepository.delete(user);
            return true;
        }
        return false;
    }

}

